import SignupPage from "./index"

export const metadata = {
  title: 'BTL Engine Signup | Signup today! It’s Free!',
  description: 'BTL Engine',
}

export default function Signup() {
  return <SignupPage />
}
