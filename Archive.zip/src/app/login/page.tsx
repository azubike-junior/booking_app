import LoginPage from './index'

export const metadata = {
  title: 'BTL Engine Login | Get in and start you book direct experience',

  description: 'BTL Engine',
}

export default function Login() {
  return <LoginPage />
}
