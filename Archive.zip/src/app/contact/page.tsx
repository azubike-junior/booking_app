import ContactPage from '.'

export const metadata = {
  title: 'Contact BTL Engine | Let’s Help You with More Direct Bookings',
  description: 'BTL Engine',
}

export default function Contact() {
  return <ContactPage />
}
