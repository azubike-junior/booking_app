
import AboutPage from '@/app/about'

export const metadata = {
  title: 'About BTL Engine | Integrate Google Free Booking Link With us',
  description: 'BTL Engine',
}

export default function About() {
  return (
    <AboutPage/>
  )
}
